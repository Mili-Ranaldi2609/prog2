package unidireccional;

public class Universidad {
    private String nombreU;

    public Universidad(String nombreU) {
        this.nombreU = nombreU;
    }

    public String getNombreU() {
        return nombreU;
    }

    public void setNombreU(String nombreU) {
        this.nombreU = nombreU;
    }
}
