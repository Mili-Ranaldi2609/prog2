package ejer2;

public interface Prestable {
    void prestar();
    void devolver();
}
