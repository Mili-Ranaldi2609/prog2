package ej9;

public class Main {
    public static void main(String[] args) {
        Circle c1=new Circle(12);
        Rectangle r1=new Rectangle(16,12);
        c1.calcularArea();
        c1.calcularPerimetro();
        r1.calcularArea();
        r1.calcularPerimetro();
    }
}
