package ej9;

public abstract class GeometricFigure {
    public void calcularArea(){

    }
    public void calcularPerimetro(){

    }
}
